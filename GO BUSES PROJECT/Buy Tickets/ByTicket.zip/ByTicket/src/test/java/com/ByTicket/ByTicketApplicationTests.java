package com.ByTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
