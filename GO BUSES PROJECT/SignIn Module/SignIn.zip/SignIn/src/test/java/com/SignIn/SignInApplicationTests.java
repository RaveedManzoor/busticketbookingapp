package com.SignIn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignInApplicationTests {

	@Test
	void contextLoads() {
	}

}
