package com.GOBUSES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GobusesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GobusesApplication.class, args);
	}

}
