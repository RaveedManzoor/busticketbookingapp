package com.Registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationModuleForGoBusesApplicationTests {

	@Test
	void contextLoads() {
	}

}
